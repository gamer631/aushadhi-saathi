import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:aushadhi_saathi/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('Aushadhi Saathi renders the elder reminder dashboard',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const AushadhiSaathiApp());
    await tester.pumpAndSettle();

    expect(find.text('औषधि साथी'), findsOneWidget);
    expect(find.text('आजको समय'), findsOneWidget);
    expect(find.text('लिनुहोस्'), findsOneWidget);
  });

  testWidgets('Family member can change and save their profile name',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const AushadhiSaathiApp());
    await tester.pumpAndSettle();

    await tester.tap(find.text('परिवार'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('edit_profile_name_button')));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(const ValueKey('profile_name_field')),
      'Sita Sharma',
    );
    await tester.tap(find.text('सेभ गर्नुहोस्'));
    await tester.pumpAndSettle();

    expect(find.text('Sita Sharma'), findsOneWidget);

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pumpWidget(const AushadhiSaathiApp());
    await tester.pumpAndSettle();
    await tester.tap(find.text('परिवार'));
    await tester.pumpAndSettle();

    expect(find.text('Sita Sharma'), findsOneWidget);
  });

  testWidgets('Family dashboard starts without a demo name', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const AushadhiSaathiApp());
    await tester.pumpAndSettle();

    await tester.tap(find.text('परिवार'));
    await tester.pumpAndSettle();

    expect(find.text('राम बहादुर'), findsNothing);
    expect(find.text('नाम थप्नुहोस्'), findsOneWidget);
  });

  testWidgets(
      'Add medicine form offers exact time and personal voice recording',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const AushadhiSaathiApp());
    await tester.pumpAndSettle();

    await tester.tap(find.text('परिवार'));
    await tester.pumpAndSettle();
    final addMedicineButton = find.text('नयाँ औषधी');
    await tester.scrollUntilVisible(
      addMedicineButton,
      250,
      scrollable: find.byType(Scrollable).last,
    );
    await tester.tap(addMedicineButton);
    await tester.pumpAndSettle();

    expect(find.text('दैनिक सम्झाउने समय'), findsOneWidget);
    final recordButton =
        find.byKey(const ValueKey('record_medicine_voice_button'));
    await tester.ensureVisible(recordButton);
    expect(recordButton, findsOneWidget);
  });
}
