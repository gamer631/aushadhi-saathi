package com.aushadhisaathi.aushadhi_saathi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
