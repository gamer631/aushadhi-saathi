import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'dose_reminder_service.dart';

void main() {
  runApp(const AushadhiSaathiApp());
}

enum DoseStatus { pending, taken, missed }

class Medicine {
  Medicine({
    required this.id,
    required this.name,
    required this.doseText,
    required this.timeOfDay,
    required this.notes,
    this.reminderHour = 8,
    this.reminderMinute = 0,
    this.voiceRecordingPath,
    this.reminderEnabled = true,
    this.status = DoseStatus.pending,
  });

  factory Medicine.fromJson(Map<String, dynamic> json) {
    return Medicine(
      id: json['id'] as String? ??
          DateTime.now().millisecondsSinceEpoch.toString(),
      name: json['name'] as String? ?? 'औषधी',
      doseText: json['doseText'] as String? ?? 'दवा',
      timeOfDay: json['timeOfDay'] as String? ?? 'सकें',
      notes: json['notes'] as String? ?? 'नोट',
      reminderHour: json['reminderHour'] as int? ?? 8,
      reminderMinute: json['reminderMinute'] as int? ?? 0,
      voiceRecordingPath: json['voiceRecordingPath'] as String?,
      reminderEnabled: json['reminderEnabled'] as bool? ?? false,
      status: DoseStatus.values.firstWhere(
        (value) =>
            value.name ==
            (json['status'] as String? ?? DoseStatus.pending.name),
        orElse: () => DoseStatus.pending,
      ),
    );
  }

  final String id;
  final String name;
  final String doseText;
  final String timeOfDay;
  final String notes;
  final int reminderHour;
  final int reminderMinute;
  final String? voiceRecordingPath;
  final bool reminderEnabled;
  DoseStatus status;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'doseText': doseText,
        'timeOfDay': timeOfDay,
        'notes': notes,
        'reminderHour': reminderHour,
        'reminderMinute': reminderMinute,
        'voiceRecordingPath': voiceRecordingPath,
        'reminderEnabled': reminderEnabled,
        'status': status.name,
      };

  Color get statusColor {
    switch (status) {
      case DoseStatus.taken:
        return Colors.green;
      case DoseStatus.missed:
        return Colors.red;
      case DoseStatus.pending:
        return Colors.orange;
    }
  }

  String get statusLabel {
    switch (status) {
      case DoseStatus.taken:
        return 'लिइएको';
      case DoseStatus.missed:
        return 'बाँकी';
      case DoseStatus.pending:
        return 'परेको';
    }
  }

  String get reminderTimeText =>
      '${reminderHour.toString().padLeft(2, '0')}:${reminderMinute.toString().padLeft(2, '0')}';
}

class AushadhiSaathiApp extends StatelessWidget {
  const AushadhiSaathiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'औषधि साथी',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E7A5A),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF4F8F2),
        appBarTheme: const AppBarTheme(centerTitle: true),
      ),
      home: const AushadhiHomePage(),
    );
  }
}

const String _medicineStorageKey = 'aushadhi_saathi_medicines_v1';
const String _voiceEnabledKey = 'aushadhi_saathi_voice_enabled';
const String _largeTextKey = 'aushadhi_saathi_large_text';
const String _profileNameKey = 'aushadhi_saathi_profile_name';
const String _legacyExampleProfileName = 'राम बहादुर';
const String _defaultProfileName = '';

List<Medicine> get defaultMedicines => [
      Medicine(
        id: '1',
        name: 'भिटामिन D',
        doseText: '१ गोली, खानाको ९:०० बजे',
        timeOfDay: 'सकें',
        notes: 'खाना पछि',
        reminderHour: 9,
        reminderMinute: 0,
        reminderEnabled: false,
        status: DoseStatus.taken,
      ),
      Medicine(
        id: '2',
        name: 'प्रेसर मेडिसिन',
        doseText: '१ गोली, बिहान ८:०० बजे',
        timeOfDay: 'सकें',
        notes: 'पानीले',
        reminderHour: 8,
        reminderMinute: 0,
        reminderEnabled: false,
        status: DoseStatus.pending,
      ),
      Medicine(
        id: '3',
        name: 'सोरि',
        doseText: '१ गोली, राति ८:०० बजे',
        timeOfDay: 'राती',
        notes: 'खाना पछि',
        reminderHour: 20,
        reminderMinute: 0,
        reminderEnabled: false,
        status: DoseStatus.missed,
      ),
    ];

class AushadhiHomePage extends StatefulWidget {
  const AushadhiHomePage({super.key});

  @override
  State<AushadhiHomePage> createState() => _AushadhiHomePageState();
}

class _AushadhiHomePageState extends State<AushadhiHomePage> {
  final List<Medicine> _medicines = [];
  bool _voiceEnabled = true;
  bool _largeText = true;
  String _profileName = _defaultProfileName;
  bool _reminderPermissionWarningShown = false;

  @override
  void initState() {
    super.initState();
    _loadSavedState();
  }

  Future<void> _loadSavedState() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_medicineStorageKey);

    if (raw == null || raw.isEmpty) {
      _medicines.addAll(defaultMedicines);
    } else {
      try {
        final decoded = jsonDecode(raw) as List<dynamic>;
        final medicines = decoded
            .map((item) => Medicine.fromJson(item as Map<String, dynamic>))
            .toList();
        _medicines.addAll(medicines);
      } catch (_) {
        _medicines.addAll(defaultMedicines);
      }
    }

    _voiceEnabled = prefs.getBool(_voiceEnabledKey) ?? true;
    _largeText = prefs.getBool(_largeTextKey) ?? true;
    final savedProfileName = prefs.getString(_profileNameKey);
    _profileName = savedProfileName == _legacyExampleProfileName
        ? _defaultProfileName
        : savedProfileName ?? _defaultProfileName;
    if (mounted) {
      setState(() {});
    }
    for (final medicine in _medicines.where((item) => item.reminderEnabled)) {
      await _scheduleReminder(medicine);
    }
  }

  Future<void> _persistState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _medicineStorageKey,
      jsonEncode(_medicines.map((medicine) => medicine.toJson()).toList()),
    );
    await prefs.setBool(_voiceEnabledKey, _voiceEnabled);
    await prefs.setBool(_largeTextKey, _largeText);
    await prefs.setString(_profileNameKey, _profileName);
  }

  void _addMedicine(Medicine medicine) {
    setState(() {
      _medicines.add(medicine);
    });
    _persistState();
    _scheduleReminder(medicine);
  }

  void _markTaken(String medicineId) {
    setState(() {
      for (final medicine in _medicines) {
        if (medicine.id == medicineId) {
          medicine.status = DoseStatus.taken;
        }
      }
    });
    _persistState();
  }

  void _deleteMedicine(String medicineId) {
    setState(() {
      _medicines.removeWhere((medicine) => medicine.id == medicineId);
    });
    _persistState();
    DoseReminderService.instance.cancel(medicineId);
  }

  Future<void> _scheduleReminder(Medicine medicine) async {
    if (!medicine.reminderEnabled) return;
    try {
      final scheduled = await DoseReminderService.instance.schedule(
        medicineId: medicine.id,
        medicineName: medicine.name,
        hour: medicine.reminderHour,
        minute: medicine.reminderMinute,
      );
      if (!mounted || scheduled || kIsWeb || _reminderPermissionWarningShown) {
        return;
      }
      _reminderPermissionWarningShown = true;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('समयमै सम्झना पाउन सूचना अनुमति दिनुहोस्।'),
        ),
      );
    } catch (error) {
      debugPrint('Could not schedule medicine reminder: $error');
      if (mounted && !_reminderPermissionWarningShown) {
        _reminderPermissionWarningShown = true;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
                'सम्झना राख्न सकिएन। सूचना अनुमति र फोन सेटिङ जाँच्नुहोस्।'),
          ),
        );
      }
    }
  }

  void _updateProfileName(String name) {
    setState(() {
      _profileName = name;
    });
    _persistState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text('औषधि साथी'),
          centerTitle: true,
          toolbarHeight: 122,
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF1E7A5A), Color(0xFF2BAA72)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(64),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: TabBar(
                dividerHeight: 0,
                indicator: BoxDecoration(
                  color: Colors.white.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(14),
                ),
                labelColor: Colors.white,
                unselectedLabelColor: Colors.white.withOpacity(0.75),
                tabs: const [
                  Tab(text: 'आजको समय'),
                  Tab(text: 'परिवार'),
                  Tab(text: 'सेटिङ्स'),
                ],
              ),
            ),
          ),
        ),
        body: SafeArea(
          child: TabBarView(
            children: [
              ElderReminderView(
                medicines: _medicines,
                onTaken: _markTaken,
                voiceEnabled: _voiceEnabled,
                largeText: _largeText,
              ),
              FamilyDashboardView(
                medicines: _medicines,
                profileName: _profileName,
                onProfileNameChanged: _updateProfileName,
                onAddMedicine: _addMedicine,
                onDeleteMedicine: _deleteMedicine,
              ),
              SettingsScreen(
                voiceEnabled: _voiceEnabled,
                largeText: _largeText,
                onVoiceChanged: (value) {
                  setState(() {
                    _voiceEnabled = value;
                  });
                  _persistState();
                },
                onLargeTextChanged: (value) {
                  setState(() {
                    _largeText = value;
                  });
                  _persistState();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ElderReminderView extends StatefulWidget {
  const ElderReminderView({
    super.key,
    required this.medicines,
    required this.onTaken,
    required this.voiceEnabled,
    required this.largeText,
  });

  final List<Medicine> medicines;
  final void Function(String medicineId) onTaken;
  final bool voiceEnabled;
  final bool largeText;

  @override
  State<ElderReminderView> createState() => _ElderReminderViewState();
}

class _ElderReminderViewState extends State<ElderReminderView>
    with WidgetsBindingObserver {
  final FlutterTts _tts = FlutterTts();
  final AudioPlayer _voicePlayer = AudioPlayer();
  final Set<String> _autoPlayedDoses = {};
  Timer? _reminderCheckTimer;
  bool _appIsResumed = true;

  Medicine? get _focusMedicine {
    if (widget.medicines.isEmpty) return null;

    final pending =
        widget.medicines.where((m) => m.status != DoseStatus.taken).toList();
    return pending.isNotEmpty ? pending.first : widget.medicines.first;
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _reminderCheckTimer = Timer.periodic(
      const Duration(seconds: 15),
      (_) => _playDueVoiceReminder(),
    );
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _playDueVoiceReminder());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _appIsResumed = state == AppLifecycleState.resumed;
    if (state == AppLifecycleState.resumed) {
      _playDueVoiceReminder();
    }
  }

  Future<void> _playMedicineVoice(Medicine medicine) async {
    final path = medicine.voiceRecordingPath;
    if (path == null || path.isEmpty) return;
    if (kIsWeb) {
      await _voicePlayer.setUrl(path);
    } else {
      await _voicePlayer.setFilePath(path);
    }
    await _voicePlayer.play();
  }

  Future<void> _playDueVoiceReminder() async {
    if (!widget.voiceEnabled || !mounted || !_appIsResumed) return;
    if (DefaultTabController.of(context).index != 0) return;
    final now = DateTime.now();
    for (final medicine in widget.medicines) {
      if (!medicine.reminderEnabled || medicine.voiceRecordingPath == null) {
        continue;
      }
      final scheduled = DateTime(
        now.year,
        now.month,
        now.day,
        medicine.reminderHour,
        medicine.reminderMinute,
      );
      final lateness = now.difference(scheduled);
      final doseKey = '${medicine.id}-${now.year}-${now.month}-${now.day}';
      if (lateness.isNegative ||
          lateness > const Duration(minutes: 2) ||
          _autoPlayedDoses.contains(doseKey)) {
        continue;
      }
      _autoPlayedDoses.add(doseKey);
      try {
        await _playMedicineVoice(medicine);
      } catch (error) {
        debugPrint('Could not play scheduled medicine voice: $error');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('रेकर्ड गरिएको आवाज चलाउन सकिएन।'),
            ),
          );
        }
      }
    }
  }

  Future<void> _speakReminder(Medicine medicine) async {
    if (!widget.voiceEnabled) return;
    try {
      if (medicine.voiceRecordingPath != null) {
        await _playMedicineVoice(medicine);
        return;
      }
      await _tts.setLanguage('ne-NP');
      await _tts.setSpeechRate(0.5);
      await _tts.speak('${medicine.name} को समय भयो। ${medicine.doseText}');
    } catch (error) {
      debugPrint('Could not play medicine reminder: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('आवाज चलाउन सकिएन।')),
        );
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _reminderCheckTimer?.cancel();
    _voicePlayer.dispose();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final target = _focusMedicine;
    if (target == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'अहिले कुनै औषधी छैन।',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
          ),
        ),
      );
    }

    final isTaken = target.status == DoseStatus.taken;
    final buttonLabel = isTaken ? 'लिइएको' : 'लिनुहोस्';
    final textScale = widget.largeText ? 1.15 : 1.0;

    return Padding(
      padding: const EdgeInsets.all(18),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isTaken
                      ? [Colors.green.shade50, Colors.white]
                      : [Colors.orange.shade50, Colors.white],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(26),
                border: Border.all(
                  color:
                      isTaken ? Colors.green.shade200 : Colors.orange.shade200,
                ),
              ),
              child: Column(
                children: [
                  Text(
                    'आजको औषधी',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    '${target.timeOfDay} • ${target.reminderTimeText}',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: isTaken
                              ? Colors.green.shade700
                              : Colors.orange.shade800,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 18),
                  Container(
                    height: 120,
                    width: 120,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.08),
                          offset: const Offset(0, 8),
                          blurRadius: 18,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.medication_rounded,
                      size: 62,
                      color: Color(0xFF1E7A5A),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    '${target.name} (${target.notes})',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    target.doseText,
                    style: TextStyle(fontSize: 18 * textScale),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'आजको सूची',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
            const SizedBox(height: 10),
            ...widget.medicines.map(
              (medicine) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: medicine.status == DoseStatus.taken
                      ? Colors.green.shade50
                      : Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: medicine.status == DoseStatus.taken
                        ? Colors.green.shade200
                        : Colors.grey.shade300,
                  ),
                ),
                child: ListTile(
                  leading: Icon(
                    medicine.status == DoseStatus.taken
                        ? Icons.check_circle_rounded
                        : Icons.pending_actions_rounded,
                    color: medicine.status == DoseStatus.taken
                        ? Colors.green
                        : Colors.orange,
                  ),
                  title: Text(medicine.name),
                  subtitle: Text(
                    '${medicine.timeOfDay} • ${medicine.reminderTimeText} • ${medicine.doseText}',
                  ),
                  trailing: Text(
                    medicine.statusLabel,
                    style: TextStyle(
                      color: medicine.statusColor,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: isTaken ? null : () => widget.onTaken(target.id),
                    icon: const Icon(Icons.check_circle_rounded),
                    label: Text(
                      buttonLabel,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w700),
                    ),
                    style: FilledButton.styleFrom(
                      backgroundColor:
                          isTaken ? Colors.green : const Color(0xFF1E7A5A),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                IconButton.filled(
                  onPressed: () => _speakReminder(target),
                  tooltip: 'आवाज सुनाउनुहोस्',
                  icon: const Icon(Icons.volume_up_rounded),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Text(
                'सुरक्षित रहनुहोस्: सबै औषधीको प्रयोगलाई डॉक्टर वा फार्मासिस्टसँग जाँच गर्नुहोस्।',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FamilyDashboardView extends StatelessWidget {
  const FamilyDashboardView({
    super.key,
    required this.medicines,
    required this.profileName,
    required this.onProfileNameChanged,
    required this.onAddMedicine,
    required this.onDeleteMedicine,
  });

  final List<Medicine> medicines;
  final String profileName;
  final ValueChanged<String> onProfileNameChanged;
  final void Function(Medicine medicine) onAddMedicine;
  final void Function(String medicineId) onDeleteMedicine;

  int get takenCount =>
      medicines.where((m) => m.status == DoseStatus.taken).length;

  Future<void> _editProfileName(BuildContext context) async {
    final name = await showDialog<String>(
      context: context,
      builder: (context) => _EditProfileNameDialog(initialName: profileName),
    );
    if (name != null) {
      onProfileNameChanged(name);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 28,
                  child: Icon(Icons.person_rounded, size: 30),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (profileName.trim().isEmpty)
                        TextButton.icon(
                          key: const ValueKey('edit_profile_name_button'),
                          onPressed: () => _editProfileName(context),
                          icon: const Icon(Icons.person_add_alt_1_rounded),
                          label: const Text('नाम थप्नुहोस्'),
                        )
                      else
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                profileName,
                                key: const ValueKey('profile_name'),
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            IconButton(
                              key: const ValueKey('edit_profile_name_button'),
                              onPressed: () => _editProfileName(context),
                              tooltip: 'नाम परिवर्तन गर्नुहोस्',
                              icon: const Icon(Icons.edit_rounded, size: 20),
                            ),
                          ],
                        ),
                      Text(
                        'आजको स्थिति: $takenCount/${medicines.length} औषधी',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _SummaryCard(
                title: 'लिइएको',
                value: '$takenCount',
                color: const Color(0xFF1E7A5A),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _SummaryCard(
                title: 'परेको',
                value:
                    '${medicines.where((m) => m.status == DoseStatus.pending).length}',
                color: Colors.orange,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _SummaryCard(
                title: 'बाँकी',
                value:
                    '${medicines.where((m) => m.status == DoseStatus.missed).length}',
                color: Colors.red,
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),
        ...medicines.map(
          (medicine) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: medicine.statusColor.withOpacity(0.14),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    medicine.status == DoseStatus.taken
                        ? Icons.check_circle_rounded
                        : Icons.medication_rounded,
                    color: medicine.statusColor,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        medicine.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${medicine.timeOfDay} • ${medicine.reminderTimeText} • ${medicine.doseText}',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  medicine.statusLabel,
                  style: TextStyle(
                    color: medicine.statusColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: () => onDeleteMedicine(medicine.id),
                  icon: const Icon(Icons.delete_outline_rounded),
                  tooltip: 'मेटाउनुहोस्',
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        FilledButton.tonalIcon(
          key: const ValueKey('add_medicine_button'),
          onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => AddMedicineScreen(onSave: onAddMedicine),
              ),
            );
          },
          icon: const Icon(Icons.add_circle_rounded),
          label: const Text('नयाँ औषधी'),
        ),
      ],
    );
  }
}

class _EditProfileNameDialog extends StatefulWidget {
  const _EditProfileNameDialog({required this.initialName});

  final String initialName;

  @override
  State<_EditProfileNameDialog> createState() => _EditProfileNameDialogState();
}

class _EditProfileNameDialogState extends State<_EditProfileNameDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.initialName);
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        widget.initialName.trim().isEmpty
            ? 'नाम थप्नुहोस्'
            : 'नाम परिवर्तन गर्नुहोस्',
      ),
      content: Form(
        key: _formKey,
        child: TextFormField(
          key: const ValueKey('profile_name_field'),
          controller: _nameController,
          autofocus: true,
          maxLength: 60,
          decoration: const InputDecoration(
            labelText: 'तपाईंको नाम',
            border: OutlineInputBorder(),
          ),
          validator: (value) {
            if (value == null || value.trim().isEmpty) {
              return 'कृपया नाम लेख्नुहोस्।';
            }
            return null;
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('रद्द गर्नुहोस्'),
        ),
        FilledButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              Navigator.of(context).pop(_nameController.text.trim());
            }
          },
          child: const Text('सेभ गर्नुहोस्'),
        ),
      ],
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({
    super.key,
    required this.voiceEnabled,
    required this.largeText,
    required this.onVoiceChanged,
    required this.onLargeTextChanged,
  });

  final bool voiceEnabled;
  final bool largeText;
  final ValueChanged<bool> onVoiceChanged;
  final ValueChanged<bool> onLargeTextChanged;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'सेटिङ्स',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 16),
                SwitchListTile.adaptive(
                  value: voiceEnabled,
                  onChanged: onVoiceChanged,
                  title: const Text('आवाज सहायताको सुविधा'),
                  subtitle: const Text('आवाजमा提醒 सुन्न मिल्छ।'),
                ),
                SwitchListTile.adaptive(
                  value: largeText,
                  onChanged: onLargeTextChanged,
                  title: const Text('ठूला अक्षर'),
                  subtitle: const Text('पढ़्न सजिलो बनाउनको लागि।'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'सुरक्षा सूचना',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                Text(
                    'औषधीको प्रयोग गर्नु अघि डॉक्टर र फार्मासिस्टसँग जाँच गर्नुहोस्।'),
                Text('औषधीको सही समय, मात्रा र खाने समयमा ध्यान दिनुहोस्।'),
                Text(
                    'हामीले दवाईको उपयोगलाई मेडिकल सल्लाहको विकल्प मान्दैनौं।'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.title,
    required this.value,
    required this.color,
  });

  final String title;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style:
                Theme.of(context).textTheme.labelLarge?.copyWith(color: color),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: color,
                ),
          ),
        ],
      ),
    );
  }
}

class AddMedicineScreen extends StatefulWidget {
  const AddMedicineScreen({super.key, required this.onSave});

  final void Function(Medicine medicine) onSave;

  @override
  State<AddMedicineScreen> createState() => _AddMedicineScreenState();
}

class _AddMedicineScreenState extends State<AddMedicineScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _doseController = TextEditingController();
  final _notesController = TextEditingController();
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _previewPlayer = AudioPlayer();
  TimeOfDay _reminderTime = const TimeOfDay(hour: 8, minute: 0);
  String? _recordingPath;
  String? _activeRecordingPath;
  bool _isRecording = false;
  Timer? _recordingLimitTimer;
  String _foodTiming = 'खाना अघि';

  @override
  void dispose() {
    _nameController.dispose();
    _doseController.dispose();
    _notesController.dispose();
    _recordingLimitTimer?.cancel();
    _recorder.dispose();
    _previewPlayer.dispose();
    super.dispose();
  }

  String get _timeOfDayLabel {
    if (_reminderTime.hour < 11) return 'बिहान';
    if (_reminderTime.hour < 16) return 'दिउँसो';
    if (_reminderTime.hour < 20) return 'साँझ';
    return 'राति';
  }

  Future<void> _selectReminderTime() async {
    final selected = await showTimePicker(
      context: context,
      initialTime: _reminderTime,
      helpText: 'औषधी खाने समय छान्नुहोस्',
    );
    if (selected != null && mounted) {
      setState(() {
        _reminderTime = selected;
      });
    }
  }

  Future<void> _toggleRecording() async {
    try {
      if (_isRecording) {
        _recordingLimitTimer?.cancel();
        final path = await _recorder.stop();
        if (!mounted) return;
        var savedPath = path ?? _activeRecordingPath;
        if (kIsWeb && path != null) {
          final response = await http.get(Uri.parse(path));
          if (response.statusCode != 200) {
            throw StateError('Unable to save browser voice recording.');
          }
          final contentType = response.headers['content-type'] ?? 'audio/webm';
          savedPath =
              'data:$contentType;base64,${base64Encode(response.bodyBytes)}';
        }
        setState(() {
          _isRecording = false;
          _recordingPath = savedPath;
          _activeRecordingPath = null;
        });
        return;
      }

      if (!await _recorder.hasPermission()) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('आवाज रेकर्ड गर्न माइक्रोफोन अनुमति चाहिन्छ।')),
          );
        }
        return;
      }

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final outputPath = kIsWeb
          ? 'medicine-voice-$timestamp.webm'
          : '${(await getApplicationDocumentsDirectory()).path}/medicine-voice-$timestamp.m4a';
      await _recorder.start(
        const RecordConfig(
          encoder: kIsWeb ? AudioEncoder.opus : AudioEncoder.aacLc,
        ),
        path: outputPath,
      );
      if (!mounted) return;
      setState(() {
        _activeRecordingPath = outputPath;
        _isRecording = true;
      });
      _recordingLimitTimer = Timer(
        const Duration(seconds: 30),
        _toggleRecording,
      );
    } catch (error) {
      debugPrint('Could not record medicine voice: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('आवाज रेकर्ड गर्न सकिएन। अनुमति जाँच्नुहोस्।')),
        );
      }
    }
  }

  Future<void> _previewRecording() async {
    final path = _recordingPath;
    if (path == null) return;
    try {
      if (kIsWeb) {
        await _previewPlayer.setUrl(path);
      } else {
        await _previewPlayer.setFilePath(path);
      }
      await _previewPlayer.play();
    } catch (error) {
      debugPrint('Could not preview medicine voice: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('रेकर्ड गरिएको आवाज चलाउन सकिएन।')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('नयाँ औषधी'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: ListView(
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'औषधीको नाम',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'औषधीको नाम आवश्यक छ।'
                      : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _doseController,
                  decoration: const InputDecoration(
                    labelText: 'मात्रा र समय',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'मात्रा र समय लेख्नुहोस्।'
                      : null,
                ),
                const SizedBox(height: 16),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.schedule_rounded),
                  title: const Text('दैनिक सम्झाउने समय'),
                  subtitle: Text(
                      '$_timeOfDayLabel • ${_reminderTime.format(context)}'),
                  trailing: const Icon(Icons.edit_calendar_rounded),
                  onTap: _selectReminderTime,
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          'आफ्नो आवाजमा सम्झना',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'परिवारको सदस्यले औषधी कसरी खाने भनेर छोटो सन्देश रेकर्ड गर्न सक्नुहुन्छ।',
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          '३० सेकेन्डसम्म रेकर्ड गर्नुहोस्। समय हुँदा एप खुला छ भने आवाज आफैं बज्छ; बन्द हुँदा फोनमा सूचना आउँछ।',
                          style: TextStyle(fontSize: 12),
                        ),
                        const SizedBox(height: 12),
                        FilledButton.tonalIcon(
                          key: const ValueKey('record_medicine_voice_button'),
                          onPressed: _toggleRecording,
                          icon: Icon(
                            _isRecording
                                ? Icons.stop_circle
                                : Icons.mic_rounded,
                          ),
                          label: Text(
                            _isRecording
                                ? 'रेकर्डिङ रोक्नुहोस्'
                                : 'आवाज रेकर्ड गर्नुहोस्',
                          ),
                        ),
                        if (_recordingPath != null) ...[
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            key:
                                const ValueKey('preview_medicine_voice_button'),
                            onPressed: _previewRecording,
                            icon: const Icon(Icons.play_arrow_rounded),
                            label: const Text('रेकर्डिङ सुनेर जाँच्नुहोस्'),
                          ),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                _recordingPath = null;
                              });
                            },
                            child: const Text('रेकर्डिङ हटाउनुहोस्'),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _foodTiming,
                  decoration: const InputDecoration(
                    labelText: 'खाना सम्बन्ध',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(
                        value: 'खाना अघि', child: Text('खाना अघि')),
                    DropdownMenuItem(
                        value: 'खाना पछि', child: Text('खाना पछि')),
                    DropdownMenuItem(
                        value: 'खाने बेलामा', child: Text('खाने बेलामा')),
                    DropdownMenuItem(
                        value: 'खाना नलगेपछि', child: Text('खाना नलगेपछि')),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _foodTiming = value;
                      });
                    }
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _notesController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'नोट/सुझाव',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: () {
                    if (!_formKey.currentState!.validate()) return;

                    final medicine = Medicine(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      name: _nameController.text.trim(),
                      doseText: _doseController.text.trim(),
                      timeOfDay: _timeOfDayLabel,
                      notes: _notesController.text.trim().isEmpty
                          ? _foodTiming
                          : '$_foodTiming • ${_notesController.text.trim()}',
                      reminderHour: _reminderTime.hour,
                      reminderMinute: _reminderTime.minute,
                      voiceRecordingPath: _recordingPath,
                    );

                    widget.onSave(medicine);
                    Navigator.of(context).pop();
                  },
                  icon: const Icon(Icons.save_rounded),
                  label: const Text('सेव गर्नुहोस्'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
