import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

class DoseReminderService {
  DoseReminderService._();

  static final DoseReminderService instance = DoseReminderService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  bool? _notificationsAllowed;
  bool? _exactAlarmsAllowed;

  bool get _supportedPlatform =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.android ||
          defaultTargetPlatform == TargetPlatform.iOS);

  Future<void> initialize() async {
    if (!_supportedPlatform || _initialized) return;

    tz_data.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Kathmandu'));
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    );
    await _plugin.initialize(settings);
    _initialized = true;
  }

  Future<bool> schedule({
    required String medicineId,
    required String medicineName,
    required int hour,
    required int minute,
  }) async {
    if (!_supportedPlatform) return false;
    await initialize();

    if (defaultTargetPlatform == TargetPlatform.android) {
      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      _notificationsAllowed ??=
          await android?.requestNotificationsPermission() ?? false;
      if (!_notificationsAllowed!) return false;

      _exactAlarmsAllowed ??=
          await android?.canScheduleExactNotifications() ?? false;
      if (!_exactAlarmsAllowed!) {
        await android?.requestExactAlarmsPermission();
        _exactAlarmsAllowed =
            await android?.canScheduleExactNotifications() ?? false;
      }
      if (!_exactAlarmsAllowed!) return false;
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      final ios = _plugin.resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin>();
      _notificationsAllowed ??= await ios?.requestPermissions(
            alert: true,
            badge: true,
            sound: true,
          ) ??
          false;
      if (!_notificationsAllowed!) return false;
    }

    final now = tz.TZDateTime.now(tz.local);
    var scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hour,
      minute,
    );
    if (!scheduledDate.isAfter(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    await _plugin.zonedSchedule(
      notificationIdFor(medicineId),
      'औषधी खाने समय भयो',
      '$medicineName खानुहोस्। आवाज सुन्न एप खोल्नुहोस्।',
      scheduledDate,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'medicine_reminders',
          'औषधी सम्झना',
          channelDescription: 'औषधी खाने समयमा सम्झाउने दैनिक सूचना',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
    return true;
  }

  Future<void> cancel(String medicineId) async {
    if (!_supportedPlatform) return;
    await initialize();
    await _plugin.cancel(notificationIdFor(medicineId));
  }

  static int notificationIdFor(String medicineId) {
    var hash = 0x811c9dc5;
    for (final unit in medicineId.codeUnits) {
      hash = ((hash ^ unit) * 0x01000193) & 0x7fffffff;
    }
    return hash;
  }
}
