# Aushadhi Saathi

Nepali-first, offline medicine reminders for elders and their families.

## GitHub Pages

The `Build and deploy web app` workflow runs Flutter analysis and tests, then publishes the release web build to GitHub Pages after each push to `main`. Enable GitHub Pages in the repository settings and select **GitHub Actions** as the build and deployment source. The workflow builds with the repository's project-site URL path.

The hosted version is a browser MVP. It does not provide browser-scheduled notifications or cross-device accounts/sync; medicine data and recordings remain on each user's device.

## Medicine reminders and voice recordings

- Add a medicine with its prescribed dose and a daily reminder time.
- Record a family or caregiver voice message (up to 30 seconds) while adding a medicine. Preview it before saving.
- On Android and iOS, the app schedules a daily local notification. Android asks for notification and exact-alarm permissions.
- When the app is open on the elder reminder screen, the saved voice message plays automatically at its reminder time. A notification appears when the app is in the background; custom voice playback in the background is not supported yet.
- Voice recordings and schedules are stored locally on that device. They are not shared between separate family phones because account pairing and cloud sync are not implemented yet.
- The browser build can record and save a voice clip in local browser storage, but browser notification delivery is not implemented.

Reminder schedules repeat every day at the selected Nepal time. Confirm each medicine and its schedule against the prescription or with a doctor or pharmacist; the app does not provide medical advice.

## Run and validate

```sh
flutter pub get
flutter run
flutter analyze
flutter test
```
